import streamlit as st
 
st.set_page_config(page_title = "Título de la web", page_icon = "😉")

st.title("Mi primera aplicación con Streamlit")

st.write("Mi nombre es *Tony Trujillo* ✌🏻️")
